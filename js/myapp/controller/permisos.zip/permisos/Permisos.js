Ext.define('myapp.controller.permisos.Permisos', { // #1 
  extend: 'Ext.app.Controller',// #2
  views: [
    'permisos.PermisosWin',
    'permisos.PermisosForm',
    'permisos.Gridbuscar',
    'permisos.Gridbuscaremp'
  ],
  stores: [
    'permisos.EmpleadosGrid'
  ],
  refs: [{
    ref: 'Gridbuscaremp',
    selector: 'gridbuscaremp'
  },{
    ref: 'Gridbuscar',
    selector: 'gridbuscar'
  },{
    ref: 'PermisosWin',
    selector: 'permisos'
  }],
  init: function() {
    this.control({
      "permisos radiogroup[name=radiopermisos]": {
        change: this.changePermiso
      },
       "permisos button[name=buscar]":  {      
        click: this.onButtonClickBuscar
      }, 
      "gridbuscaremp button#agregar": {
        click: this.onButtonClickagregar
      }, 
      "permisos  combobox[name=cmbtiposolicitud]": {
        select: this.selecttiposolicitud
      }
    });
  },


  onButtonClickBuscar:function (button, e, options) {
    var win=Ext.create('myapp.view.permisos.Gridbuscar');
    win.show();
  },
  onButtonClickagregar: function (button, e, options) {
    var grid = this.getGridbuscaremp();
    var win=this.getGridbuscar();
    record = grid.getSelectionModel().getSelection();
    grid.close();
    win.close();
    if(record[0]){ // #2
      var editWindow = Ext.create('myapp.view.permisos.PermisosForm');
      editWindow.down('form').getForm().reset();
      editWindow.down('form').loadRecord(record[0]);
      //editWindow.down('textfield[name=nacionalidad]').setReadOnly(true);
      editWindow.show();
    }
  },
  selecttiposolicitud:function(button, combobox, e, options){
    var formPanel = button.up('form');
    tipo = formPanel.down("combobox[name=cmbtiposolicitud]").getValue();
    console.log(tipo);
    if (tipo==1){
      formPanel.down("fieldset[itemId=tipopermiso]").setVisible(true);
      formPanel.down("fieldset[itemId=motivo]").setVisible(true);
      formPanel.down("fieldset[itemId=reposos]").setVisible(false);
    }else{
      if (tipo==2){
        formPanel.down("fieldset[itemId=reposos]").setVisible(true);
        formPanel.down("fieldset[itemId=tipopermiso]").setVisible(false);
        formPanel.down("fieldset[itemId=motivo]").setVisible(true);
      }
    }
  },
  changePermiso:function(grupo,cmp){
    var formPanel1 = grupo.up('window');
    var formPanel = grupo.up('form')
    var reportes = Ext.ComponentQuery.query("#radiopermisos [name=tipoperm]");
    var  valor=(reportes[0].getGroupValue());
    console.log(valor);
    switch (valor) {
      case 1:
      formPanel.down("numberfield[name=dias]").setVisible(true);
      formPanel.down("datefield[name=fechadesde]").setVisible(true);
      formPanel.down("datefield[name=fechahasta]").setVisible(true);
       formPanel.down("timefield[name=salida]").setVisible(false);
      formPanel.down("timefield[name=entrada]").setVisible(false);
      break; 
      case 2:
      formPanel.down("timefield[name=salida]").setVisible(false);
      formPanel.down("timefield[name=entrada]").setVisible(true);
       formPanel.down("numberfield[name=dias]").setVisible(false);
      formPanel.down("datefield[name=fechadesde]").setVisible(false);
      formPanel.down("datefield[name=fechahasta]").setVisible(false);
      break; 
      case 3:
      formPanel.down("timefield[name=salida]").setVisible(true);
      formPanel.down("timefield[name=entrada]").setVisible(false);
      formPanel.down("numberfield[name=dias]").setVisible(false);
      formPanel.down("datefield[name=fechadesde]").setVisible(false);
      formPanel.down("datefield[name=fechahasta]").setVisible(false);
      break; 
        
   }
  },
});

